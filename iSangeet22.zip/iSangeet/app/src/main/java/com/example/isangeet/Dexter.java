package com.example.isangeet;

public class Dexter {
    public static void withContext(MainActivity mainActivity) {

    }
}
